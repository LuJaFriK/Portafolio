import java.util.Scanner;
public class Madera_Fina{
    public static void main (String[]args){
        Scanner teclado = new Scanner(System.in);
        System.out.println("Registrar una puerta nueva");
        Puerta puerta1 = new Puerta();
        Puerta puerta1
    }
    public void ticket(){
        
    }
}