public class Puerta{
    private String madera;
    //las medidas van en milimetros
    private int altura;
    private int anchura;
    private int grosor=45;
    private double precio;
    private String[] tiposmaderas={"Pino","Cedro","Roble"};
    
    public Puerta() {
        madera = this.tiposmaderas[0];
        altura = 2030;
        anchura = 825;
        precio = 2436.90;
    }

    public String getMadera() {
        return madera;
    }

    public void setMadera(int t) {
        this.madera = tiposmaderas[t];
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getAnchura() {
        return anchura;
    }

    public void setAnchura(int anchura) {
        this.anchura = anchura;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
}
